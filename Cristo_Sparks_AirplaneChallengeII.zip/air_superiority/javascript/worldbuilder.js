//random number generator for enemy spawn points
function rng(max,min){
    return Math.floor(Math.random()* (max-min +1))+min;
}
//start points
var player = {
    left: 350,
    top: 620
}
var enemies = [
    {left: rng(100, 800), top: 15},
    {left: rng(100, 800), top: 15},
    {left: rng(100, 800), top: 15},
    {left: rng(100, 800), top: 15}
]

var missiles = []

//creating characters
function drawPlayer() {
    content = "<div class='player' style='left: "+player.left+"px; top: "+player.top+"px'></div>";
    document.getElementById("players").innerHTML = content;
}
function drawEnemies() {
    content = "";
    for(var idx=0; idx<enemies.length; idx++) {
        content += "<div class='enemy' style='left: "+enemies[idx].left+"px; top: "+enemies[idx].top+"px'></div>";
    }
    document.getElementById("enemies").innerHTML = content;
}
function drawMissiles() {
    content = "";
    for(var idx=0; idx<missiles.length; idx++) {
        content += "<div class='missile' style='left: "+missiles[idx].left+"px; top: "+missiles[idx].top+"px'></div>";
    }
    document.getElementById("missiles").innerHTML = content;
}

//moving enemies and missiles
function moveEnemies() {
    for(var idx=0; idx<enemies.length; idx++) {
        enemies[idx].top += 3;
    }
}
function moveMissiles() {
    for(var idx=0; idx<missiles.length; idx++) {
        missiles[idx].top -= 20;
    }
}

//control scheme
document.onkeydown = function(e) {
    if(e.keyCode == 65) {//left
        if(player.left > 0) {
            player.left -= 12;
        }
    }
    if(e.keyCode == 68) {//right
        if(player.left < 900) {
            player.left += 12;
        }
    }
    if(e.keyCode == 87) {//up
        if(player.top > 500) {
            player.top -= 15;
        }
    }
    if(e.keyCode == 83) {//down
        if(player.top < 625) {
            player.top += 15;
        }
    }
    if(e.keyCode == 13) {//fire
        missiles.push({left: player.left+35, top: player.top-3});
        drawMissiles();
    }
    drawPlayer();
}

//game cycle
function gameLoop() {
    moveEnemies();
    moveMissiles();
    drawPlayer();
    drawEnemies();
    drawMissiles();
    setTimeout(gameLoop, 50);
}
gameLoop();