//Random Number Generator

function rng(max,min){
    return Math.floor(Math.random()* (max-min +1))+min;
    }


/* This is the Javascript created to build the world. var world is the layout of the future map while
worldDict determines the what goes in each square of the map. drawWorld generates the map on the webpage. */

var world = [
            [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
            [1,2,2,1,1,3,2,1,1,2,2,2,2,2,2,2,1,3,1,1,2,1],
            [1,1,2,2,1,1,3,2,2,2,2,2,2,1,1,3,2,2,2,2,2,1],
            [1,1,2,1,1,2,1,1,3,2,1,1,1,1,1,1,1,1,1,2,2,1],
            [1,2,2,2,1,2,2,2,2,2,1,1,1,2,2,2,2,2,3,3,3,1],
            [1,1,2,2,1,2,2,2,3,3,1,1,1,2,2,1,1,1,1,1,1,1],
            [1,1,2,2,1,2,2,2,2,1,1,1,1,2,2,1,1,1,1,1,1,1],
            [1,2,2,2,1,2,2,2,2,2,2,1,1,2,2,1,1,1,1,1,1,1],
            [1,2,3,2,1,1,1,1,1,1,2,2,2,2,2,2,2,1,1,3,3,1],
            [1,2,3,1,1,1,1,1,1,1,2,2,2,2,2,2,2,1,1,2,2,1],
            [1,2,3,2,2,2,2,2,2,2,2,2,2,1,1,1,1,1,1,2,2,1],
            [1,2,2,2,1,2,2,2,2,2,2,2,2,1,1,1,1,1,2,2,2,1],
            [1,2,1,2,2,2,2,2,1,1,1,1,1,3,3,3,3,3,3,3,3,1],
            [1,2,1,2,1,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,1],
            [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
        ];
        var worldDict = {
            0: 'blank',
            1: 'wall',
            2: 'sushi',
            3: 'onigiri'
        }

        function drawWorld(){
            output = "";

            for(var row = 0; row < world.length; row++){
                output += "<div class = 'row' >"
                for(var x = 0; x < world[row].length; x++){
                    output += "<div class = '" + worldDict[world[row][x]] +"' ></div>"
                    
                }
                output += "</div>"
            }
            document.getElementById('world').innerHTML = output;
            document.getElementById("score").innerHTML = "Score: " +points;
            document.getElementById("lives").innerHTML = "Lives: " +lives;
        }
        drawWorld();

//places characters in the world.
var ninjaman = {
        x: 1,
        y: 1
}

    function drawNinjaman(){
        document.getElementById('ninjaman').style.top =
            ninjaman.y * 40 + 'px'
        document.getElementById('ninjaman').style.left =
            ninjaman.x * 40 + 'px'
    }
drawNinjaman()

var bluey = {
    x: 10,
    y: 1
}

var pinky = {
    x: 20,
    y: 12
}
function drawGoons() {
        document.getElementById("bluey").style.left = 
        bluey.x * 40+"px";
        document.getElementById("bluey").style.top = 
        bluey.y * 40+"px";
        document.getElementById("pinky").style.left = 
        pinky.x * 40+"px";
        document.getElementById("pinky").style.top = 
        pinky.y * 40+"px";
}
drawGoons()
//creating the move cycle for the two goons. adjust speed with moveCycle.
function moveBluey(){
    var move = rng(-1,4);
        if(move ===0 && (world[bluey.y][bluey.x-1] !==1)){//0 = left
          bluey.x--;
        } 
        else if(move ===1 && (world[bluey.y][bluey.x+1] !==1)){//1 = right
          bluey.x++;
        }
        else if(move ===2 && (world[bluey.y-1][bluey.x] !==1)){//2 = up
         bluey.y--;
        }
        else if(move ===3 && (world[bluey.y+1][bluey.x] !==1)){//3 = down
         bluey.y++;
        }
}
function movePinky(){
    var move = rng(-1,4);
        if(move ===0 && (world[pinky.y][pinky.x-1] !==1)){//0 = left
         pinky.x--;
        } 
        else if(move ===1 && (world[pinky.y][pinky.x+1] !==1)){//1 = right
         pinky.x++;
        }
        else if(move ===2 && (world[pinky.y-1][pinky.x] !==1)){//2 = up
         pinky.y--;
        }
        else if(move ===3 && (world[pinky.y+1][pinky.x] !==1)){//3 = down
         pinky.y++;
        }
}
function moveCycle() {
    drawNinjaman();
    drawGoons();
    moveBluey();
    movePinky();
    drawGoons();
    setTimeout(moveCycle, 350)
  }

//Block of code for point system
var points = 0;
console.log("Points:"+points);




//Create live system
var lives = 3;
console.log("lives:"+lives);



// This assigns movement for the ninjaman character
document.onkeydown = function(e){
    if(e.keyCode == 37) { // LEFT
        if(world[ninjaman.y][ninjaman.x - 1] != 1){
            ninjaman.x--;
        }
    }
    if(e.keyCode == 39){ // RIGHT
        if(world[ninjaman.y][ninjaman.x + 1] != 1){
            ninjaman.x++;
        }        
    }
    if(e.keyCode == 40){ // DOWN
        if(world[ninjaman.y + 1][ninjaman.x] != 1){
            ninjaman.y++;
        }
    }
    if(e.keyCode == 38){ // UP
        if(world[ninjaman.y - 1][ninjaman.x] != 1){
            ninjaman.y--;
    }
        }
//block of code to add points
    if(world[ninjaman.y][ninjaman.x] === 2){
            world[ninjaman.y][ninjaman.x] =0;
            points+=10;
            console.log("Points:"+points);}
        else if(world[ninjaman.y][ninjaman.x] === 3){
            world[ninjaman.y][ninjaman.x] =0;
            points+=35;
            console.log("Points:"+points);
           }
//block to lose lives by touching the two ghosts           
    if((ninjaman.x === pinky.x) && (ninjaman.y === pinky.y)){
            lives -=1;
          console.log("lives:"+lives)
          }
    if((ninjaman.x === bluey.x) && (ninjaman.y === bluey.y)){
            lives -=1;
          console.log("lives:"+lives)
          }
//failstate
    if(lives ===0){
            alert("All your base belongs to us! Your Score is "+points)
            }
    drawNinjaman()
    drawWorld()


}
moveCycle();
    

    
