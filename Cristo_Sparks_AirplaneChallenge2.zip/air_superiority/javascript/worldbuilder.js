//random number generator for enemy spawn points and movement
function rng(max,min){
    return Math.floor(Math.random()* (max-min +1))+min;
}
//start points
var player = {
    left: 350,
    top: 620
}
var enemies = [
    {left: rng(100, 800), top: 15},
    {left: rng(100, 800), top: 15},
    {left: rng(100, 800), top: 15},
    {left: rng(100, 800), top: 15}
]

var missiles = []

//creating characters
function drawPlayer() {
    content = "<div class='player' style='left: "+player.left+"px; top: "+player.top+"px'></div>";
    document.getElementById("players").innerHTML = content;
}
function drawEnemies() {
    content = "";
    for(var idx=0; idx<enemies.length; idx++) {
        content += "<div class='enemy' style='left: "+enemies[idx].left+"px; top: "+enemies[idx].top+"px'></div>";
    }
    document.getElementById("enemies").innerHTML = content;
}
function nextWave(){
    enemies.push({left: rng(100, 800) , top: 15});
        drawEnemies();
}
function drawMissiles() {
    content = "";
    for(var idx=0; idx<missiles.length; idx++) {
        content += "<div class='missile' style='left: "+missiles[idx].left+"px; top: "+missiles[idx].top+"px'></div>";
    }
    document.getElementById("missiles").innerHTML = content;
}

//moving enemies and missiles
function moveEnemies() {
    for(var idx=0; idx<enemies.length; idx++) {
        enemies[idx].top += 3;
    }
}
function strafe(){
    for(var idx=0; idx<enemies.length; idx++){
        var move = rng(-1,6);
        if(move ===0){//0 = left
            enemies[idx].left -= 6;
        } 
        else if(move ===1){//1 = right
            enemies[idx].left += 6;
        }
        else if(move ===2){//2 = left
            enemies[idx].left -= 4;
        } 
        else if(move ===3){//3 = right
            enemies[idx].left += 4;
        }
        else if(move ===4){//4 = left
            enemies[idx].left -= 2;
        } 
        else if(move ===5){//5 = right
            enemies[idx].left += 2;
        }
    }
}
function moveMissiles() {
    for(var idx=0; idx<missiles.length; idx++) {
        missiles[idx].top -= 20;
    }
}

//control scheme
document.onkeydown = function(e) {
    if(e.keyCode == 65) {//left
        if(player.left > 0) {
            player.left -= 15;
        }
    }
    if(e.keyCode == 68) {//right
        if(player.left < 900) {
            player.left += 15;
        }
    }
    if(e.keyCode == 87) {//up
        if(player.top > 500) {
            player.top -= 17;
        }
    }
    if(e.keyCode == 83) {//down
        if(player.top < 625) {
            player.top += 10;
        }
    }
    if(e.keyCode == 81) {//left+fire
        if(player.left > 0) {
            player.left -= 8;
            missiles.push({left: player.left+35, top: player.top-3});
            drawMissiles();
        }
    }
    if(e.keyCode == 69) {//right+fire
        if(player.left < 900) {
            player.left += 8;
            missiles.push({left: player.left+35, top: player.top-3});
            drawMissiles();
        }
    }
    if(e.keyCode == 13) {//fire
        missiles.push({left: player.left+35, top: player.top-3});
        drawMissiles();
    }
    drawPlayer();
}
//Block of code for point system
var points = 0;
console.log("Points:"+points);

if((missiles.top === enemies.top) && (missiles.left === enemies.left)){
    points +=100;
  console.log("Points:"+points)
}


//Create live system
var lives = 3;
console.log("lives:"+lives);

if((player.top === enemies.top) && (player.left === enemies.left)){
    lives -=1;
  console.log("lives:"+lives)
}
if((enemies.top === 700)){
    lives -=1;
  console.log("lives:"+lives)
}
if(lives ===0){
    alert("All your base belongs to us! Your Score= "+points)
}

//game cycles
function gameLoop() {
    moveEnemies();
    moveMissiles();
    drawPlayer();
    drawEnemies();
    drawMissiles();
    setTimeout(gameLoop, 50);
}
gameLoop();
function strafeLoop() {
    strafe();
    setTimeout(strafeLoop, rng(100, 350));
}
strafeLoop();
function spawnWave() {
    var wave = rng(-1,6);
        if(wave ===0){//0 = 1 su74
            nextWave();
        } 
        else if(wave ===1){//1 = 2 su74s
            nextWave();
            nextWave();
        }
        else if(wave ===2){//2 = 3 su74s
            nextWave();
            nextWave();
            nextWave();
        } 
        else if(wave ===3){//3 = 3 su74s
            nextWave();
            nextWave();
            nextWave();
        }
        else if(wave ===4){//4 = 4 su74s
            nextWave();
            nextWave();
            nextWave();
            nextWave();
        } 
        else if(wave ===5){//5 = 5 su74s
            nextWave();
            nextWave();
            nextWave();
            nextWave();
            nextWave();
        }
    setTimeout(spawnWave, rng(2000, 5000))
}
spawnWave();